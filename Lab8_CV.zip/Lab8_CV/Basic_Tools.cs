﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_CV
{
    public class Basic_Tools
    {
        public static void Pause()
        {
            //Pauses the program so the user can read the data
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }
    }
}
